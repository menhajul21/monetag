export interface MaintenanceSettings {
    isMaintenance: boolean;
    title?: string;
    message?: string;
    estimatedTime?: string;
} 