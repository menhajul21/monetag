export const FETCH_WITHDRAWAL_DATA_REQUEST = 'withdrawal/FETCH_DATA_REQUEST';
export const FETCH_WITHDRAWAL_DATA_SUCCESS = 'withdrawal/FETCH_DATA_SUCCESS';
export const FETCH_WITHDRAWAL_DATA_FAILURE = 'withdrawal/FETCH_DATA_FAILURE';
export const SET_SELECTED_METHOD = 'withdrawal/SET_SELECTED_METHOD';
export const SET_SELECTED_COIN = 'withdrawal/SET_SELECTED_COIN';
export const RESET_WITHDRAWAL = 'withdrawal/RESET'; 